-- By Mahan_Tnta

ALTER TABLE `users`
ADD COLUMN `kits` INT(11) NOT NULL DEFAULT '0';