-- By Mahan_Tnta

fx_version 'cerulean'
game 'gta5' 

author 'Mahan_Tnta'
description 'Kits'
version '1.0'


client_scripts {
    'client.lua',
}

server_scripts {
    'server.lua',
    '@mysql-async/lib/MySQL.lua'
}

-- سلام داش دختری ؟