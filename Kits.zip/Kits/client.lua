-- By Mahan_Tnta

ESX = nil

CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj)
            ESX = obj
        end)
        Wait(0)
    end
end)

RegisterNetEvent('open:kitsmenu')
AddEventHandler('open:kitsmenu', function()
    OpenKitsMenu()
end)

function OpenKitsMenu()
    local elements = {
        {label = 'Starter Pack', value = 'starter'},
        {label = 'VIP Pack', value = 'vip'},
    }

    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'kitsmenu', {
        title    = 'Kits',
        align    = 'center',
        elements = elements
    }, function(data, menu)
        if data.current.value == 'starter' then
            TriggerServerEvent('kits:starter')
            menu.close()
        elseif data.current.value == 'vip' then
            TriggerServerEvent('kits:vip')
            menu.close()
        end
    end, function(data, menu)
        menu.close()
    end)
end