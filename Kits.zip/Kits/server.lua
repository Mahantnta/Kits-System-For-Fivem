-- By Mahan_Tnta

ESX = nil
TriggerEvent('esx:getSharedObject', function(obj)
    ESX = obj
end)

local StarterItems = {
    {name = 'phone', amount = 1},
    {name = 'water', amount = 5},
    {name = 'bread', amount = 5},
}

RegisterCommand('kits', function(src)
    if ESX ~= nil then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            TriggerClientEvent('open:kitsmenu', src)
        end
    else
    end
end)

RegisterNetEvent('kits:starter')
AddEventHandler('kits:starter', function()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    MySQL.Async.fetchAll('SELECT * FROM users WHERE identifier = @identifier', {
        ['@identifier'] = xPlayer.identifier
    }, function(result)
        if result[1] and (result[1].kits == nil or result[1].kits == 0) then
            TriggerClientEvent('chatMessage', src, '[KITS]', {255, 255, 0}, '^2Shoma Starter Pack Ra Daryaft Kardid !')

            xPlayer.addMoney(5000000)

            for _, item in ipairs(StarterItems) do
                xPlayer.addInventoryItem(item.name, item.amount)
            end

            MySQL.Async.execute('UPDATE users SET kits = @kit WHERE identifier = @identifier', {
                ['@identifier'] = xPlayer.identifier,
                ['@kit'] = 1
            })
        else
            TriggerClientEvent('chatMessage', src, '[KITS]', {255, 0, 0}, '^1Shoma Dar Halen Hazer Az In Starter Pack Estefade Kardid !!')
        end
    end)
end)

RegisterNetEvent('kits:vip')
AddEventHandler('kits:vip', function()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    local group = xPlayer.getGroup()

    if group == 'stremer' then
        TriggerClientEvent('chatMessage', src, '[KITS]', {0, 255, 255}, '^2Shoma VIP Pack Ra Daryaft Kardid !')

        xPlayer.addMoney(10000000)
        xPlayer.addInventoryItem('weapon_pistol', 1)
    else
        TriggerClientEvent('chatMessage', src, '[KITS]', {255, 0, 0}, '^1Shoma Dastresi Be VIP Pack Nadarid !!')
    end
end)